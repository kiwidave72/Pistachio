﻿#include "adapters/ui/ImGuiAdapter.h"
#include "core/Application.h"

#include <imgui.h>
#include <imgui_internal.h>
#include <GLFW/glfw3.h>
#define GLFW_EXPOSE_NATIVE_WIN32
#include <GLFW/glfw3native.h>

#include <cstring>
#include <algorithm>

#include "../Roboto-Regular.embed"
#include "UI.h"

namespace adapters {

    // ------------------------------------------------------------
    // ctor / dtor
    // ------------------------------------------------------------

    ImGuiAdapter::ImGuiAdapter(core::Application* app, GLFWwindow* hostWindow)
        : m_app(app), m_window(hostWindow)
    {
    }

    ImGuiAdapter::~ImGuiAdapter() = default;

    // ------------------------------------------------------------
    // SAFE ONE-TIME RESOURCE INIT (fonts etc)
    // ------------------------------------------------------------

    void ImGuiAdapter::initializeResources()
    {
        if (m_resourcesInitialized)
            return;

        ImGuiIO& io = ImGui::GetIO();

        ImFontConfig cfg;
        cfg.FontDataOwnedByAtlas = false;

        // Default font
        if (!io.FontDefault)
        {
            io.FontDefault = io.Fonts->AddFontFromMemoryTTF(
                (void*)g_RobotoRegular,
                sizeof(g_RobotoRegular),
                17.0f,
                &cfg
            );
        }

        // Small UI font
        if (!m_smallFont)
        {
            m_smallFont = io.Fonts->AddFontFromMemoryTTF(
                (void*)g_RobotoRegular,
                sizeof(g_RobotoRegular),
                14.0f,
                &cfg
            );
        }
        std::shared_ptr<Walnut::Image> m_IconMinimize = std::make_shared<Walnut::Image>("icons/minimize.png");
        std::shared_ptr<Walnut::Image> m_IconMaximize = std::make_shared<Walnut::Image>("icons/maximize.png");
        std::shared_ptr<Walnut::Image> m_IconRestore = std::make_shared<Walnut::Image>("icons/restore.png");
        std::shared_ptr<Walnut::Image> m_IconClose = std::make_shared<Walnut::Image>("icons/close.png");

      /*  host.setWindowControlIcons(
            m_IconMinimize->GetDescriptorSet(),
            m_IconMaximize->GetDescriptorSet(),
            m_IconRestore->GetDescriptorSet(),
            m_IconClose->GetDescriptorSet(),
            ImVec2(16, 16)
        );*/

        m_resourcesInitialized = true;
    }

    // ------------------------------------------------------------
    // FRAME RENDER (NO FONT MUTATION HERE)
    // ------------------------------------------------------------

    void ImGuiAdapter::render()
    {
        // ⚠️ DO NOT touch ImGuiIO.Fonts here
        printf("[PLUGIN] ctx=%p io=%p\n", (void*)ImGui::GetCurrentContext(), (void*)&ImGui::GetIO());
         //renderMainMenu();
        renderStatusBar();
        renderModelInfo();
        render3DView();
        renderSketchEditor();
    }

    // ------------------------------------------------------------
    // UI SECTIONS (unchanged behavior)
    // ------------------------------------------------------------

    void ImGuiAdapter::setMenubarCallback(const std::function<void()>& cb)
    {
        m_MenubarCallback = cb;
    }

    void ImGuiAdapter::renderMainMenu()
    {
        ImGui::Begin("File Operations");

        static char filePath[512] = {};
        ImGui::InputTextWithHint("##file", "STEP file path...", filePath, sizeof(filePath));

        if (ImGui::Button("Load STEP"))
        {
            if (m_app && filePath[0])
                m_app->loadFile(filePath);
        }

        ImGui::End();
    }

    void ImGuiAdapter::renderStatusBar()
    {
        ImGui::Begin("Status", nullptr, ImGuiWindowFlags_NoScrollbar);

        if (m_app)
            ImGui::Text("Status: %s", m_app->getStatus().c_str());

        ImGui::End();
    }

    void ImGuiAdapter::renderModelInfo()
    {
        ImGui::Begin("Model Info");

        if (!m_app)
        {
            ImGui::TextDisabled("No application");
            ImGui::End();
            return;
        }

        auto model = m_app->getCurrentModel();
        if (!model)
        {
            ImGui::TextDisabled("No model loaded");
            ImGui::End();
            return;
        }

        ImGui::Text("Model loaded");
        ImGui::End();
    }

    void ImGuiAdapter::render3DView()
    {
        ImGui::Begin("3D Viewport");

        if (m_app && m_app->getRenderer())
        {
            ImVec2 size = ImGui::GetContentRegionAvail();
            void* tex = m_app->getRenderer()->getFramebufferTexture();
            if (tex)
                ImGui::Image(tex, size);
        }
        else
        {
            ImGui::TextDisabled("No renderer");
        }

        ImGui::End();
    }

    void ImGuiAdapter::renderSketchEditor()
    {
        ImGui::Begin("Sketch Editor");
        ImGui::Text("Sketch UI goes here");
        ImGui::End();
    }

} // namespace adapters
