﻿#include "core/Application.h"
#include "adapters/ui/ImGuiAdapter.h"

#include <GLFW/glfw3.h>
#include <imgui.h>

// ------------------------------
// ABI-facing host/service structs
// ------------------------------
struct UiHostServices {
    void* app;    // core::Application*
    void* window; // GLFWwindow*
};

struct IUiModule {
    virtual ~IUiModule() = default;
    virtual void onLoad(UiHostServices&) = 0;
    virtual void onUnload(UiHostServices&) = 0;
    virtual void render(UiHostServices&) = 0;
};

#ifdef _WIN32
#define PISTACHIO_UI_EXPORT extern "C" __declspec(dllexport)
#else
#define PISTACHIO_UI_EXPORT extern "C"
#endif

// ------------------------------
// Concrete module implementation
// ------------------------------
class PistachioUiModule final : public IUiModule {
public:
    PistachioUiModule() = default;
    ~PistachioUiModule() override = default;

    void onLoad(UiHostServices& svc) override {
        if (m_adapter) return;

        if (ImGui::GetCurrentContext() == nullptr) {
            // if this triggers, plugin is being loaded before host CreateContext()
            printf("[UI] onLoad: no ImGui context\n");
        }
        auto* app = reinterpret_cast<core::Application*>(svc.app);
        auto* win = reinterpret_cast<GLFWwindow*>(svc.window);

        m_adapter = new adapters::ImGuiAdapter(app, win);

        // IMPORTANT: only do resource/font setup BEFORE first NewFrame
        // Your host must call module->onLoad() before ImGui::NewFrame().
        m_adapter->initializeResources();
    }

    void onUnload(UiHostServices&) override {
        delete m_adapter;
        m_adapter = nullptr;
    }

    void render(UiHostServices&) override {
        if (!m_adapter) return;
        IM_ASSERT(ImGui::GetCurrentContext() != nullptr);
        IM_ASSERT(ImGui::GetFrameCount() >= 0); // should be increasing each frame

        ImGui::Begin("UI Plugin Alive");
        ImGui::Text("FrameCount: %d", ImGui::GetFrameCount());
        ImGui::End();

        m_adapter->render();
    }

private:
    adapters::ImGuiAdapter* m_adapter = nullptr;
};

// ------------------------------
// Required exports the loader wants
// ------------------------------
PISTACHIO_UI_EXPORT IUiModule* pistachio_create_ui_module()
{
    return new PistachioUiModule();
}

PISTACHIO_UI_EXPORT void pistachio_destroy_ui_module(IUiModule* m)
{
    delete m;
}
