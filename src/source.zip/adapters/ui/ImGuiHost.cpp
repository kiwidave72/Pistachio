﻿#include "ImGuiHost.h"

#include "../ImGui/ImGuiTheme.h"
#include "../ImGui/Image.h"


#include <imgui.h>
#include "imgui_internal.h"

#include <backends/imgui_impl_glfw.h>
#include <backends/imgui_impl_opengl3.h>
#include "../Roboto-Regular.embed"
#include "../../../Walnut-Icon.embed"
#include "../../../WindowImages.embed"

#include "UI.h"
#include <GLFW/glfw3.h>
#include "stb_image.h"

#define GLFW_EXPOSE_NATIVE_WIN32
#include <GLFW/glfw3native.h>

#include <cstdio>
#include <cassert>


namespace HostUI
{
    inline void ShiftCursorY(float offsetY)
    {
        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + offsetY);
    }

    inline ImRect GetItemRect()
    {
        return ImRect(ImGui::GetItemRectMin(), ImGui::GetItemRectMax());
    }

    inline ImRect RectExpanded(const ImRect& r, float x, float y)
    {
        ImRect out = r;
        out.Min.x -= x; out.Min.y -= y;
        out.Max.x += x; out.Max.y += y;
        return out;
    }

    // Minimal "draw an image like a button" helper.
    // You can pass different tints for normal/hovered/pressed.
    inline void DrawButtonImage(
        ImTextureID tex,
        const ImVec2& size,
        ImU32 tintNormal,
        ImU32 tintHovered,
        ImU32 tintPressed
    )
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        const ImRect r(ImGui::GetItemRectMin(), ImGui::GetItemRectMax());

        const bool hovered = ImGui::IsItemHovered();
        const bool held = ImGui::IsItemActive();

        ImU32 tint = held ? tintPressed : (hovered ? tintHovered : tintNormal);
        dl->AddImage(tex, r.Min, r.Max, ImVec2(0, 0), ImVec2(1, 1), tint);
    }
}

namespace adapters {

    // Track whether ImGuiHost created the GLFW window (so we can destroy it)
    static bool g_ownsGlfwWindow = false;
    static bool g_glfwInitedByHost = false;

    // ============================================================
    // helpers
    // ============================================================

    static void PrintGLFWState(GLFWwindow* w)
    {
        if (!w) {
            std::printf("[ImGuiHost] GLFW window = NULL\n");
            return;
        }

        int ww = 0, wh = 0;
        int fbw = 0, fbh = 0;
        glfwGetWindowSize(w, &ww, &wh);
        glfwGetFramebufferSize(w, &fbw, &fbh);

        int visible = glfwGetWindowAttrib(w, GLFW_VISIBLE);
        int iconified = glfwGetWindowAttrib(w, GLFW_ICONIFIED);

        std::printf(
            "[ImGuiHost]   Window=%dx%d FB=%dx%d Visible=%d Iconified=%d\n",
            ww, wh, fbw, fbh, visible, iconified
        );
    }

    static GLFWwindow* CreateHostWindow()
    {
        // If GLFW isn't initialized by someone else, initialize it here.
        if (!glfwInit()) {
            std::printf("[ImGuiHost][ERROR] glfwInit() failed (cannot create UI window)\n");
            return nullptr;
        }

        g_glfwInitedByHost = true;

        const char* glsl_version = "#version 130";
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
        glfwWindowHint(GLFW_TITLEBAR, false);

#if defined(__APPLE__)
        glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

        GLFWwindow* w = glfwCreateWindow(1280, 800, "Pistachio - CAD Converter", nullptr, nullptr);
        if (!w) {
            std::printf("[ImGuiHost][ERROR] glfwCreateWindow() failed\n");
            return nullptr;
        }

        glfwMakeContextCurrent(w);
        glfwSwapInterval(1); // vsync

       

        // Load embedded Roboto font
       // ImFontConfig fontConfig;
       // fontConfig.FontDataOwnedByAtlas = false;
       // io.FontDefault = io.Fonts->AddFontFromMemoryTTF((void*)g_RobotoRegular, sizeof(g_RobotoRegular), 17.0f, &fontConfig);
     /*   m_smallFont = io.Fonts->AddFontFromMemoryTTF((void*)g_RobotoRegular, sizeof(g_RobotoRegular), 14.0f, &fontConfig);

        m_ToolBarLineIcon = LoadIcon("assets/icons/SketchTwoPointLine_256.png");
        m_ToolBarCircleIcon = LoadIcon("assets/icons/SketchTwoPointCircle_256.png");
        m_ToolBarArcIcon = LoadIcon("assets/icons/SketchTwoPointArc_256.png");
        m_ToolBarRectIcon = LoadIcon("assets/icons/SketchTwoPointRectangle_256.png");*/
        g_ownsGlfwWindow = true;

        std::printf("[ImGuiHost] Created host GLFW window successfully\n");
        PrintGLFWState(w);

        return w;
    }

    // ============================================================
    // ctor / dtor
    // ============================================================

    ImGuiHost::ImGuiHost()
    {
        if (m_diagStdout)
            std::printf("[ImGuiHost] ctor\n");
    }

    ImGuiHost::~ImGuiHost()
    {
        if (m_diagStdout)
            std::printf("[ImGuiHost] dtor\n");
    }

    // ============================================================
    // initialization
    // ============================================================

    bool ImGuiHost::initialize()
    {
        if (m_initialized)
            return true;

        if (m_diagStdout)
            std::printf("[ImGuiHost] >>> initialize()\n");

        // 1) Prefer explicitly assigned window
        // 2) Fall back to current context if available
        if (!m_window)
            m_window = glfwGetCurrentContext();

        // If still no window/context, create our own GLFW UI window.
        if (!m_window) {
            std::printf(
                "[ImGuiHost][WARN] No current GLFW context. Creating a dedicated ImGui GLFW window...\n"
            );
            m_window = CreateHostWindow();
            if (!m_window) {
                std::printf(
                    "[ImGuiHost][ERROR] Failed to create GLFW window/context for ImGui.\n"
                );
                return false;
            }
        }

        // Ensure context is current now
        glfwMakeContextCurrent(m_window);

        IMGUI_CHECKVERSION();
        ImGui::CreateContext();

        ImGuiIO& io = ImGui::GetIO();

        // Docking is fine
        io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;

        // IMPORTANT: Disable multi-viewport to avoid monitor assertion in your imgui fork
        io.ConfigFlags &= ~ImGuiConfigFlags_ViewportsEnable;

        io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
  
        ImGui::StyleColorsDark();

        ImGui_ImplGlfw_InitForOpenGL(m_window, true);

        ImGui_ImplOpenGL3_Init("#version 330");
         
        // windows icons
        {
            uint32_t w, h;
            void* data = Walnut::Image::Decode(g_WalnutIcon, sizeof(g_WalnutIcon), w, h);
            if (data) {
                m_AppHeaderIcon = std::make_shared<Walnut::Image>(w, h, Walnut::ImageFormat::RGBA, data);
                // Free the decoded data (Image has copied it)
                stbi_image_free(data);
            }
        }



        m_initialized = true;

        diagPrintInitState();

        if (m_diagStdout)
            std::printf("[ImGuiHost] <<< initialize()\n");

        return true;
    }

    void ImGuiHost::shutdown()
    {
        if (!m_initialized)
            return;

        if (m_diagStdout)
            std::printf("[ImGuiHost] >>> shutdown()\n");

        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplGlfw_Shutdown();
        ImGui::DestroyContext();

        m_initialized = false;

        // If we created the GLFW window, destroy it.
        if (g_ownsGlfwWindow && m_window) {
            std::printf("[ImGuiHost] Destroying owned GLFW window\n");
            glfwDestroyWindow(m_window);
            m_window = nullptr;
            g_ownsGlfwWindow = false;
        }

        // Only terminate GLFW if we initialized it AND GLFW is only used for the ImGui window.
        if (g_glfwInitedByHost) {
            std::printf("[ImGuiHost] glfwTerminate() (host initialized GLFW)\n");
            glfwTerminate();
            g_glfwInitedByHost = false;
        }

        if (m_diagStdout)
            std::printf("[ImGuiHost] <<< shutdown()\n");
    }

    // ============================================================
    // diagnostics helpers
    // ============================================================

    void ImGuiHost::diagPrintInitState()
    {
        if (!m_diagStdout)
            return;

        ImGuiIO& io = ImGui::GetIO();

        std::printf("[ImGuiHost] ImGui ctx=%p\n", (void*)ImGui::GetCurrentContext());
        std::printf("[ImGuiHost] BackendPlatform=%s\n", io.BackendPlatformName);
        std::printf("[ImGuiHost] BackendRenderer=%s\n", io.BackendRendererName);

        PrintGLFWState(m_window);
    }

    void ImGuiHost::diagPrintFrameState(const char* stage)
    {
        if (!m_diagStdout)
            return;

        ImGuiIO& io = ImGui::GetIO();

        std::printf(
            "[ImGuiHost] frame=%llu stage=%s ctx=%p\n"
            "  DisplaySize=%.0f,%.0f DeltaTime=%.6f "
            "WantCaptureMouse=%d WantCaptureKeyboard=%d\n",
            (unsigned long long)m_frameIndex,
            stage,
            (void*)ImGui::GetCurrentContext(),
            io.DisplaySize.x,
            io.DisplaySize.y,
            io.DeltaTime,
            (int)io.WantCaptureMouse,
            (int)io.WantCaptureKeyboard
        );

        PrintGLFWState(m_window);
    }

    void ImGuiHost::diagCheckAndRestoreGlfwContext(const char* stage)
    {
        if (glfwGetCurrentContext() != m_window) {
            std::printf(
                "[ImGuiHost][WARN] GLFW context changed before %s — restoring\n",
                stage
            );
            glfwMakeContextCurrent(m_window);
        }
    }

    void ImGuiHost::diagCheckOpenGLErrors(const char* stage)
    {
        if (!m_diagStdout)
            return;

        GLenum err;
        while ((err = glGetError()) != GL_NO_ERROR) {
            std::printf(
                "[ImGuiHost][GL ERROR] stage=%s code=0x%X\n",
                stage,
                err
            );
        }
    }

    // ============================================================
    // frame lifecycle
    // ============================================================

    bool ImGuiHost::shouldClose()
    {
        return m_window ? glfwWindowShouldClose(m_window) : true;
    }
    bool ImGuiHost::IsMaximized() const
    {
        return (bool)glfwGetWindowAttrib(m_window, GLFW_MAXIMIZED);
    }

    void ImGuiHost::beginFrame()
    {
        ++m_frameIndex;

        if (m_diagStdout)
            std::printf("[ImGuiHost] >>> beginFrame frame=%llu\n",
                (unsigned long long)m_frameIndex);

        // Always ensure our UI window/context is current BEFORE backend NewFrame
        glfwMakeContextCurrent(m_window);

        diagCheckAndRestoreGlfwContext("beginFrame");

        glfwPollEvents();

        // ---- GLFW -> ImGui input bridge (robust; survives callback stomping) ----
        ImGuiIO& io = ImGui::GetIO();

        double mx, my;
        glfwGetCursorPos(m_window, &mx, &my);

#if IMGUI_VERSION_NUM >= 18700
        io.AddMousePosEvent((float)mx, (float)my);
        io.AddMouseButtonEvent(0, glfwGetMouseButton(m_window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS);
        io.AddMouseButtonEvent(1, glfwGetMouseButton(m_window, GLFW_MOUSE_BUTTON_RIGHT) == GLFW_PRESS);
        io.AddMouseButtonEvent(2, glfwGetMouseButton(m_window, GLFW_MOUSE_BUTTON_MIDDLE) == GLFW_PRESS);
#else
        io.MousePos = ImVec2((float)mx, (float)my);
        io.MouseDown[0] = (glfwGetMouseButton(m_window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS);
        io.MouseDown[1] = (glfwGetMouseButton(m_window, GLFW_MOUSE_BUTTON_RIGHT) == GLFW_PRESS);
        io.MouseDown[2] = (glfwGetMouseButton(m_window, GLFW_MOUSE_BUTTON_MIDDLE) == GLFW_PRESS);
#endif

        // Backend NewFrame (recommended order: GLFW then renderer)
        ImGui_ImplGlfw_NewFrame();
        ImGui_ImplOpenGL3_NewFrame();

        // Robust DisplaySize update (don’t rely on backend when other systems swap contexts)
        {
            int ww = 0, wh = 0;
            int fbw = 0, fbh = 0;
            glfwGetWindowSize(m_window, &ww, &wh);
            glfwGetFramebufferSize(m_window, &fbw, &fbh);

            io.DisplaySize = ImVec2((float)ww, (float)wh);

            // If you need this, re-enable (usually ok to keep on)
             if (ww > 0 && wh > 0) {
                 io.DisplayFramebufferScale = ImVec2((float)fbw / (float)ww, (float)fbh / (float)wh);
             }

            if (m_diagStdout && (m_frameIndex <= 3)) {
                std::printf("[ImGuiHost] DisplaySize set from GLFW = %dx%d (FB=%dx%d)\n", ww, wh, fbw, fbh);
            }
        }

        ImGui::NewFrame();

        const float titlebarHeight = 50.0f;

        // =========================
        // Titlebar (top fixed area)
        // =========================
        {
            ImGuiWindowFlags titlebar_flags =
                ImGuiWindowFlags_NoTitleBar |
                ImGuiWindowFlags_NoResize |
                ImGuiWindowFlags_NoMove |
                ImGuiWindowFlags_NoScrollbar |
                ImGuiWindowFlags_NoScrollWithMouse |
                ImGuiWindowFlags_NoDocking |
                ImGuiWindowFlags_NoSavedSettings;

            ImGuiViewport* viewport = ImGui::GetMainViewport();
            ImGui::SetNextWindowPos(viewport->Pos);
            ImGui::SetNextWindowSize(ImVec2(viewport->Size.x, titlebarHeight));
            ImGui::SetNextWindowViewport(viewport->ID);

            ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.0f, 0.0f));

            ImGui::Begin("##Titlebar", nullptr, titlebar_flags);
            {
                const bool isMaximized = IsMaximized();
                const float titlebarVerticalOffset = isMaximized ? -6.0f : 0.0f;
                const ImVec2 windowPadding = ImGui::GetCurrentWindow()->WindowPadding;

                ImGui::SetCursorPos(ImVec2(windowPadding.x, windowPadding.y + titlebarVerticalOffset));
                const ImVec2 titlebarMin = ImGui::GetCursorScreenPos();
                const ImVec2 titlebarMax = {
                    ImGui::GetCursorScreenPos().x + ImGui::GetWindowWidth() - windowPadding.y * 2.0f,
                    ImGui::GetCursorScreenPos().y + titlebarHeight
                };

                auto* bgDrawList = ImGui::GetBackgroundDrawList();
                auto* fgDrawList = ImGui::GetForegroundDrawList();

                bgDrawList->AddRectFilled(titlebarMin, titlebarMax, UI::Colors::Theme::titlebar);
                fgDrawList->AddRect(titlebarMin, titlebarMax, UI::Colors::Theme::invalidPrefab);

                // Logo
                {
                    const int logoWidth = 48;
                    const int logoHeight = 48;
                    const ImVec2 logoOffset(16.0f + windowPadding.x, 5.0f + windowPadding.y + titlebarVerticalOffset);
                    const ImVec2 logoRectStart = { ImGui::GetItemRectMin().x + logoOffset.x, ImGui::GetItemRectMin().y + logoOffset.y };
                    const ImVec2 logoRectMax = { logoRectStart.x + logoWidth, logoRectStart.y + logoHeight };

                    fgDrawList->AddImage(m_AppHeaderIcon->GetDescriptorSet(), logoRectStart, logoRectMax);
                }
                ImGui::BeginHorizontal("Titlebar", { ImGui::GetWindowWidth() - windowPadding.y * 2.0f, ImGui::GetFrameHeightWithSpacing() });

                static float moveOffsetX;
                static float moveOffsetY;
                const float w = ImGui::GetContentRegionAvail().x;
                const float buttonsAreaWidth = 94;

                // Title bar drag area
                // On Windows we hook into the GLFW win32 window internals
                ImGui::SetCursorPos(ImVec2(windowPadding.x, windowPadding.y + titlebarVerticalOffset)); // Reset cursor pos
                // DEBUG DRAG BOUNDS
                //fgDrawList->AddRect(ImGui::GetCursorScreenPos(), ImVec2(ImGui::GetCursorScreenPos().x + w - buttonsAreaWidth, ImGui::GetCursorScreenPos().y + titlebarHeight), UI::Colors::Theme::invalidPrefab);
                ImGui::InvisibleButton("##titleBarDragZone", ImVec2(w - buttonsAreaWidth, titlebarHeight));

                m_TitleBarHovered = ImGui::IsItemHovered();

                const bool dragZoneHovered = ImGui::IsItemHovered(ImGuiHoveredFlags_RectOnly);
                const bool dragZoneClicked = ImGui::IsItemClicked(ImGuiMouseButton_Left); // first press
                // or: const bool dragZoneActive = ImGui::IsItemActive();

#ifdef _WIN32
                if (dragZoneClicked)  // only begin a drag when click begins in the zone
                {
                    HWND hwnd = glfwGetWin32Window(m_window);

                    // Optional: ignore double-click if you use it for maximize/restore
                    // if (ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) { ... }

                    ReleaseCapture();
                    SendMessage(hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
                }
#endif


                if (isMaximized)
                {
                    float windowMousePosY = ImGui::GetMousePos().y - ImGui::GetCursorScreenPos().y;
                    if (windowMousePosY >= 0.0f && windowMousePosY <= 5.0f)
                        m_TitleBarHovered = true; // Account for the top-most pixels which don't register
                }

                // Draw Menubar
                // TODO DN menu callbacks
                /*if (m_MenubarCallback)
                {
                    ImGui::SuspendLayout();
                    {
                        ImGui::SetItemAllowOverlap();
                        const float logoHorizontalOffset = 16.0f * 2.0f + 48.0f + windowPadding.x;
                        ImGui::SetCursorPos(ImVec2(logoHorizontalOffset, 6.0f + titlebarVerticalOffset));
                        UI_DrawMenubar();

                        if (ImGui::IsItemHovered())
                            m_TitleBarHovered = false;
                    }

                    ImGui::ResumeLayout();
                }*/

                {
                    // Centered Window title
                    ImVec2 currentCursorPos = ImGui::GetCursorPos();
                    ImVec2 textSize = ImGui::CalcTextSize("m_Specification");
                    ImGui::SetCursorPos(ImVec2(ImGui::GetWindowWidth() * 0.5f - textSize.x * 0.5f, 2.0f + windowPadding.y + 6.0f));
                    ImGui::Text("%s", "m_Specification"); // Draw title
                    ImGui::SetCursorPos(currentCursorPos);
                }
 
                // Window buttons
                const ImU32 buttonColN = UI::Colors::ColorWithMultipliedValue(UI::Colors::Theme::text, 0.9f);
                const ImU32 buttonColH = UI::Colors::ColorWithMultipliedValue(UI::Colors::Theme::text, 1.2f);
                const ImU32 buttonColP = UI::Colors::Theme::textDarker;
                const float buttonWidth = 14.0f;
                const float buttonHeight = 14.0f;

                //// Minimize Button

                ImGui::Spring();
                HostUI::ShiftCursorY(8.0f);
                {
                    const int iconWidth = 16;// m_IconMinimize->GetWidth();
                    const int iconHeight = 16;// m_IconMinimize->GetHeight();
                    const float padY = (buttonHeight - (float)iconHeight) / 2.0f;
                    if (ImGui::InvisibleButton("Minimize", ImVec2(iconWidth, iconHeight)))
                    {
                        // TODO: move this stuff to a better place, like Window class
                        if (m_window)
                        {
                            glfwIconifyWindow(m_window);
                            // we need to send the event so that Application knows its minimizing.
                            //   // Application::Get().QueueEvent([windowHandle = m_Window]() { glfwIconifyWindow(windowHandle); });
                        }
                    }

                    HostUI::DrawButtonImage(m_iconMinimize, ImVec2(16, 16), buttonColN, buttonColH, buttonColP);//, HostUI::RectExpanded(HostUI::GetItemRect(), 0.0f, -padY));
                }


                //// Maximize Button
                ImGui::Spring(-1.0f, 17.0f);
                HostUI::ShiftCursorY(8.0f);
                {
                    const int iconWidth = 16;// m_IconMaximize->GetWidth();
                    const int iconHeight = 16;// m_IconMaximize->GetHeight();

                    const bool isMaximized = IsMaximized();

                    if (ImGui::InvisibleButton("Maximize", ImVec2(iconWidth, iconHeight)))
                    {

                        if (isMaximized)
                            glfwRestoreWindow(m_window);
                        else
                            glfwMaximizeWindow(m_window);

                        // TOO DN add event queue
                       /* Application::Get().QueueEvent([isMaximized, windowHandle = m_WindowHandle]()
                            {
                                if (isMaximized)
                                    glfwRestoreWindow(windowHandle);
                                else
                                    glfwMaximizeWindow(windowHandle);
                            });*/
                    }

                    HostUI::DrawButtonImage(isMaximized ? m_iconRestore : m_iconMaximize, ImVec2(16, 16), buttonColN, buttonColH, buttonColP);
                }

                // Close Button
                ImGui::Spring(-1.0f, 15.0f);
                HostUI::ShiftCursorY(8.0f);
                {
                    const int iconWidth = 16;// m_IconClose->GetWidth();
                    const int iconHeight = 16;// m_IconClose->GetHeight();
                    if (ImGui::InvisibleButton("Close", ImVec2(iconWidth, iconHeight)))
                    {
                        glfwSetWindowShouldClose(m_window, GLFW_TRUE);
                        // TODO DN send the event to the application
                       //Application::Get().Close();
                    }
                    HostUI::DrawButtonImage(m_iconClose, ImVec2(16, 16), UI::Colors::Theme::text, UI::Colors::ColorWithMultipliedValue(UI::Colors::Theme::text, 1.4f), buttonColP);
                }

                ImGui::Spring(-1.0f, 18.0f);
                ImGui::EndHorizontal();

                // Debug (optional)
                // printf("[HOST] ctx=%p io=%p\n", (void*)ImGui::GetCurrentContext(), (void*)&ImGui::GetIO());
            }
            ImGui::End();

            ImGui::PopStyleVar(3);
        }

        // ===========================================
        // Dockspace root (ONLY below the titlebar)
        // ===========================================
        {
            ImGuiViewport* vp = ImGui::GetMainViewport();

            const ImVec2 dockPos(vp->Pos.x, vp->Pos.y + titlebarHeight);
            const ImVec2 dockSize(vp->Size.x, vp->Size.y - titlebarHeight);

            ImGui::SetNextWindowPos(dockPos);
            ImGui::SetNextWindowSize(dockSize);
            ImGui::SetNextWindowViewport(vp->ID);

            ImGuiWindowFlags host_flags =
                ImGuiWindowFlags_NoTitleBar |
                ImGuiWindowFlags_NoCollapse |
                ImGuiWindowFlags_NoResize |
                ImGuiWindowFlags_NoMove |
                ImGuiWindowFlags_NoBringToFrontOnFocus |
                ImGuiWindowFlags_NoNavFocus |
                ImGuiWindowFlags_NoDocking |
                ImGuiWindowFlags_NoSavedSettings; // remove later if you want ini persistence

            ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));

            ImGui::Begin("##HostDockRoot", nullptr, host_flags);
            ImGui::PopStyleVar(3);

            ImGuiID dock_id = ImGui::GetID("MainDockspace");
            ImGui::DockSpace(dock_id, ImVec2(0, 0), ImGuiDockNodeFlags_PassthruCentralNode);

            ImGui::End();
        }

        // Host menubar callback (if you want it in titlebar area, call it inside that block)
        if (m_menubarCallback)
            m_menubarCallback();
    }

    void ImGuiHost::render()
    {
        // Host does not render content; plugins do.
        if (m_diagStdout) {
            std::printf("[ImGuiHost] render() frame=%llu\n",
                (unsigned long long)m_frameIndex);
        }

      
    }

    void ImGuiHost::endFrame()
    {
        if (m_diagStdout)
            std::printf("[ImGuiHost] >>> endFrame frame=%llu\n",
                (unsigned long long)m_frameIndex);

        ImGui::Render();

        ImDrawData* dd = ImGui::GetDrawData();
        if (m_diagStdout) {
            if (dd) {
                std::printf(
                    "[ImGuiHost] DrawData: CmdLists=%d Vtx=%d Idx=%d DisplaySize=%.0f,%.0f\n",
                    dd->CmdListsCount,
                    dd->TotalVtxCount,
                    dd->TotalIdxCount,
                    dd->DisplaySize.x,
                    dd->DisplaySize.y
                );

                if (dd->CmdListsCount == 0) {
                    std::printf("[ImGuiHost][WARN] zero command lists (no UI submitted)\n");
                }
            }
            else {
                std::printf("[ImGuiHost][WARN] DrawData is NULL\n");
            }
        }

        // Always ensure our UI window/context is current before rendering
        glfwMakeContextCurrent(m_window);

        diagCheckOpenGLErrors("before RenderDrawData");

        int fbw = 0, fbh = 0;
        glfwGetFramebufferSize(m_window, &fbw, &fbh);
        glViewport(0, 0, fbw, fbh);
        glClear(GL_COLOR_BUFFER_BIT);

        ImGui_ImplOpenGL3_RenderDrawData(dd);

        // Viewports disabled, so no platform windows block here.

        glfwSwapBuffers(m_window);

        diagCheckOpenGLErrors("after RenderDrawData");

        if (m_diagStdout)
            std::printf("[ImGuiHost] <<< endFrame\n");
    }

    // ============================================================
    // misc
    // ============================================================

    void ImGuiHost::setMenubarCallback(const std::function<void()>& menubarCallback)
    {
        m_menubarCallback = menubarCallback;
    }
    void ImGuiHost::setWindowControlIcons(
        ImTextureID minimize,
        ImTextureID maximize,
        ImTextureID restore,
        ImTextureID close,
        ImVec2 size
    )
    {
        m_iconMinimize = minimize;
        m_iconMaximize = maximize;
        m_iconRestore = restore;
        m_iconClose = close;
        m_iconSize = size;
    }


} // namespace adapters

