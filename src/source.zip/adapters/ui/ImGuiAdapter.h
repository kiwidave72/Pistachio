﻿#pragma once

#include <memory>
#include <functional>
#include "ImGuiHost.h"

struct GLFWwindow;
struct ImFont;

namespace core { class Application; }

namespace adapters {

    class ImGuiAdapter {
    public:
        ImGuiAdapter(core::Application* app, GLFWwindow* hostWindow);
        ~ImGuiAdapter();

        // NEW: must be called once, before first ImGui::NewFrame()
        void initializeResources();

        void render();

        void setMenubarCallback(const std::function<void()>& menubarCallback);

    private:
        
        void renderMainMenu();
        void renderStatusBar();
        void renderModelInfo();
        void render3DView();
        void renderCameraGizmo();
        void renderSketchEditor();

    private:
        core::Application* m_app = nullptr;
        GLFWwindow* m_window = nullptr;

        bool m_resourcesInitialized = false; // NEW

        std::function<void()> m_MenubarCallback;

        // fonts
        ::ImFont* m_smallFont = nullptr;


        // rest of your existing members unchanged…
    };

} // namespace adapters
