﻿#include <iostream>
#include <memory>
#include "core/Application.h"
#include "adapters/ui/ImGuiHost.h"
#include "adapters/ui/plugins/UiModuleApi.h"
#include "adapters/ui/plugins/UiPluginLoader.h"
#include "ports/IUIPort.h"
#include "adapters/loaders/StepFileLoader.h"
#include "adapters/exporters/ObjExporter.h"
#include "adapters/exporters/StlExporter.h"
#include "adapters/rendering/OcctRenderer.h"
#include "adapters/persistence/JsonSketchDocumentAdapter.h"
#include "adapters/solvers/BasicConstraintSolver.h"
#include <filesystem>
#include <iostream>

int main(int argc, char** argv) {
    try {
        std::cout << "===========================================\n";
        std::cout << "          Pistachio CAD Converter\n";
        std::cout << "     Hexagonal Architecture Demo\n";
        std::cout << "===========================================\n\n";
        

        std::cout << "CWD: " << std::filesystem::current_path().string() << std::endl;

        auto app = std::make_unique<core::Application>();
        
        // Configure adapters following hexagonal architecture
        std::cout << "Configuring adapters...\n";

        // main.cpp (or wherever HotReloadUiAdapter lives)

        class HotReloadUiAdapter : public ports::IUIPort
        {
        public:
            HotReloadUiAdapter(
                adapters::ImGuiHost& host,
                adapters::ui::plugins::UiPluginLoader& loader,
                adapters::ui::plugins::UiPluginServices& services)
                : m_host(host), m_loader(loader), m_services(services)
            {
            }

            // ---------- IUIPort ----------
            ports::UiPluginStatus getUiPluginStatus() const override
            {
                ports::UiPluginStatus s{};
                s.enabled = m_enabled;
                s.loaded = m_loader.isLoaded();
                s.lastError = m_loader.lastError();
                s.manifestId = m_loader.manifestId();
                s.manifestName = m_loader.manifestName();
                s.manifestVersion = m_loader.manifestVersion();
                s.featureGroup = m_loader.manifestFeatureGroup();
                return s;
            }

            void setUiPluginEnabled(bool enabled) override
            {
                if (m_enabled != enabled)
                {
                    m_enabled = enabled;
                    m_enableChangeRequested = true;
                }
            }

            void requestHotReloadUiPlugin() override
            {
                if (m_enabled)
                    m_reloadRequested = true;
            }

            // ---------- FRAME ENTRY POINT ----------
            void beginFrame()
            {
                // 🔴 SAFE POINT — MUST RUN BEFORE ANY ImGui backend NewFrame calls
                if (m_enableChangeRequested || m_reloadRequested)
                {
                    glfwMakeContextCurrent(m_host.window());

                    if (m_enableChangeRequested)
                    {
                        m_enableChangeRequested = false;

                        if (m_enabled)
                            m_loader.load(m_services);
                        else
                            m_loader.unload();
                    }
                    else if (m_reloadRequested)
                    {
                        m_reloadRequested = false;
                        m_loader.reload(m_services);
                    }

                    // 🔴 CRITICAL: restore ImGui font validity
                    ImGuiIO& io = ImGui::GetIO();
                    io.Fonts->Build();

                    ImGui_ImplOpenGL3_DestroyFontsTexture();
                    ImGui_ImplOpenGL3_CreateFontsTexture();
                }

                // Now it is SAFE to enter ImGui frame
                m_host.beginFrame();
            }

            void endFrame()
            {
                m_host.endFrame();
            }

        private:
            adapters::ImGuiHost& m_host;
            adapters::ui::plugins::UiPluginLoader& m_loader;
            adapters::ui::plugins::UiPluginServices& m_services;
           
            bool m_enabled = true;
            bool m_reloadRequested = false;
            bool m_enableChangeRequested = false;
        };



        app->setUIAdapter(std::make_unique<HotReloadUiAdapter>(app.get()));
        app->setRenderer(std::make_unique<adapters::OcctRenderer>());
        app->addFileLoader(std::make_unique<adapters::StepFileLoader>());
        app->addExporter(std::make_unique<adapters::ObjExporter>());
        app->addExporter(std::make_unique<adapters::StlExporter>());
        app->setResolverAdapter(std::make_unique<adapters::solver::BasicConstraintSolver>());


        std::cout << "Initializing application...\n";
        if (!app->initialize()) {
            std::cerr << "Failed to initialize application\n";
            return 1;
        }

        std::cout << "Setup application menus...\n";
        app->setupToolbarMenus();

        std::cout << "Load Sketch Document...\n";
        if (!app->loadSketchDocument("test.pistachio.json")) {
            std::cout << "[WARN] test.pistachio.json not found - creating default sketch document\n";
            app->createDefaultSketchDocument();
        }

        
        //adapters::persistence::JsonSketchDocumentAdapter io;
        //auto doc = io.loadDocument("../test.pistachio.json");
        //io.saveDocument(*doc, "out.pistachio.json");*/


        std::cout << "Application started successfully!\n";
        std::cout << "Press ESC or close window to exit\n\n";
        
        app->runSolver();
        
        
        app->run();
        
        std::cout << "\nShutting down...\n";
        app->shutdown();
        
        std::cout << "Application closed successfully\n";
        return 0;
        
    } catch (const std::exception& e) {
        std::cerr << "Fatal error: " << e.what() << "\n";
        return 1;
    }
}